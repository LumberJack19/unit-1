//initialize function called when the script loads
//the script below creates the cities
function initialize(){ //Use it like a maestro; decide which functions need to run
	jsAjax();
 };

function jsAjax(){
	// Step 1: Define the data request
	var request = new Request('MegaCities.geojson');
		//Step 2: define Fetch parameters 
var init = {
	method: 'GET'
}
//Step 3: use Fetch to retrieve data
fetch(request, init)
.then(response => response.text())//this is the part I wanna study
.then(callback) //Step 4 Send retrieved data to a callback function
};

//define callback function
function callback(response){
//tasks using the data go here
console.log(response)
document.querySelector('#mydiv').insertAdjacentHTML('beforeend',response); //alt: document.querySelector('#mydiv').id = "newdiv";
}
document.addEventListener('DOMContentLoaded',initialize)
//call the initialize function when the window has loaded
window.onload = initialize();